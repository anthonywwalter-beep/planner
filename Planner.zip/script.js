
const taskInput = document.getElementById('input-box');
const dateTimeInput = document.getElementById('datetime-input');
const listContainer = document.getElementById('list-container');
const calendar = document.getElementById('calendar');
const monthDisplay = document.getElementById('monthDisplay');
const prevMonthBtn = document.getElementById('prevMonth');
const nextMonthBtn = document.getElementById('nextMonth');

let currentDate = new Date();
let selectedMonth = currentDate.getMonth();
let selectedYear = currentDate.getFullYear();

// Initialize calendar and show tasks on page load
window.onload = () => {
    showTask();
    renderCalendar();
    updateTasksOnCalendar();
};

// Calendar navigation
prevMonthBtn.addEventListener('click', () => {
    selectedMonth--;
    if (selectedMonth < 0) {
        selectedMonth = 11;
        selectedYear--;
    }
    renderCalendar();
    updateTasksOnCalendar();
});

nextMonthBtn.addEventListener('click', () => {
    selectedMonth++;
    if (selectedMonth > 11) {
        selectedMonth = 0;
        selectedYear++;
    }
    renderCalendar();
    updateTasksOnCalendar();
});

function renderCalendar() {
    const firstDay = new Date(selectedYear, selectedMonth, 1);
    const lastDay = new Date(selectedYear, selectedMonth + 1, 0);
    const startingDay = firstDay.getDay();
    const monthLength = lastDay.getDate();
    
    // Update month display
    const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 
                       'July', 'August', 'September', 'October', 'November', 'December'];
    monthDisplay.textContent = `${monthNames[selectedMonth]} ${selectedYear}`;
    
    // Clear calendar
    calendar.innerHTML = '';
    
    // Add empty cells for days before start of month
    for (let i = 0; i < startingDay; i++) {
        const emptyDay = document.createElement('div');
        emptyDay.classList.add('calendar-day', 'empty');
        calendar.appendChild(emptyDay);
    }
    
    // Add days of the month
    for (let day = 1; day <= monthLength; day++) {
        const dayElement = document.createElement('div');
        dayElement.classList.add('calendar-day');
        dayElement.innerHTML = `
            <div class="day-number">${day}</div>
            <div class="day-tasks"></div>
        `;
        dayElement.setAttribute('data-date', `${selectedYear}-${(selectedMonth + 1).toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}`);
        calendar.appendChild(dayElement);
    }
}


function updateTasksOnCalendar() {
    // Clear all tasks from calendar
    document.querySelectorAll('.day-tasks').forEach(el => el.innerHTML = '');
    
    // Get all tasks and add them to calendar
    const tasks = Array.from(listContainer.children);
    tasks.forEach(task => {
        const taskText = task.querySelector('strong').textContent;
        const taskDate = new Date(task.querySelector('small').textContent);
        const dateString = taskDate.toISOString().split('T')[0];
        
        const dayElement = document.querySelector(`.calendar-day[data-date="${dateString}"]`);
        if (dayElement) {
            const tasksContainer = dayElement.querySelector('.day-tasks');
            const taskDot = document.createElement('div');
            taskDot.classList.add('task-dot');
            taskDot.title = taskText;
            if (task.classList.contains('completed')) {
                taskDot.classList.add('completed');
            }
            tasksContainer.appendChild(taskDot);
        }
    });
}

function addTask() {
    const task = taskInput.value.trim();
    const datetime = dateTimeInput.value;

    if (task === '' || datetime === '') {
        alert('Please enter both a task and a date/time.');
        return;
    }

    const li = document.createElement('li');
    li.innerHTML = `
        <div>
            <strong>${task}</strong><br><small>${new Date(datetime).toLocaleString()}</small>
        </div>
        <button class="remove-btn" title="Remove task">✖</button>
    `;
    li.querySelector('.remove-btn').onclick = function(e) {
        e.stopPropagation();
        removeTask(li);
    };
    li.addEventListener('click', function(e) {
        if (e.target.tagName !== 'BUTTON') {
            li.classList.toggle('completed');
            saveData();
            updateTasksOnCalendar();
        }
    });
    listContainer.appendChild(li);
    saveData();
    updateTasksOnCalendar();
    taskInput.value = '';
    dateTimeInput.value = '';
}


function removeTask(element) {
    element.remove();
    saveData();
    updateTasksOnCalendar();
}


function saveData() {
    localStorage.setItem("tasks", listContainer.innerHTML);
}

function showTask() {
    listContainer.innerHTML = localStorage.getItem("tasks") || "";
    // Re-attach remove button event listeners after loading from localStorage
    Array.from(listContainer.querySelectorAll('.remove-btn')).forEach(btn => {
        btn.onclick = function(e) {
            e.stopPropagation();
            removeTask(btn.parentElement);
        };
    });
    // Re-attach completed toggle
    Array.from(listContainer.children).forEach(li => {
        li.addEventListener('click', function(e) {
            if (e.target.tagName !== 'BUTTON') {
                li.classList.toggle('completed');
                saveData();
            }
        });
    });
}